18 DOMAIN DATASETS CREATED FROM data_inventory_1000.csv
=================================================================

Source rows: 1000
Source columns: 111

Important: the source inventory is a wide, candidate-level/summary dataset.
Therefore these files are domain-wise extracts, not newly invented transactional
records. Fields that require event-level detail (e.g., individual interviews,
tasks, project artifacts, invoices) are represented only by the summary fields
available in the source inventory.

01_Student_Member: 1000 rows x 12 columns -> 01_Student_Member.csv
02_Assessment: 1000 rows x 16 columns -> 02_Assessment.csv
03_Attendance_Engagement: 1000 rows x 7 columns -> 03_Attendance_Engagement.csv
04_Projects: 1000 rows x 7 columns -> 04_Projects.csv
05_Project_Registry_Artifacts: 1000 rows x 4 columns -> 05_Project_Registry_Artifacts.csv
06_Sprint_Task: 1000 rows x 8 columns -> 06_Sprint_Task.csv
07_Rubrics_Reviews: 1000 rows x 5 columns -> 07_Rubrics_Reviews.csv
08_Domain_Expert: 1000 rows x 5 columns -> 08_Domain_Expert.csv
09_Program_Manager: 1000 rows x 10 columns -> 09_Program_Manager.csv
10_Talent_Registry: 1000 rows x 8 columns -> 10_Talent_Registry.csv
11_Mock_Interviews: 1000 rows x 9 columns -> 11_Mock_Interviews.csv
12_Jobs_Placement: 1000 rows x 9 columns -> 12_Jobs_Placement.csv
13_Institution_CoE: 12 rows x 7 columns -> 13_Institution_CoE.csv
14_Commercial_Payments: 1000 rows x 12 columns -> 14_Commercial_Payments.csv
15_Admissions_Enquiries: 1000 rows x 6 columns -> 15_Admissions_Enquiries.csv
16_Platform_Usage: 1000 rows x 10 columns -> 16_Platform_Usage.csv
17_Challenge_Registry: 1000 rows x 5 columns -> 17_Challenge_Registry.csv
18_Faculty: 1000 rows x 6 columns -> 18_Faculty.csv
